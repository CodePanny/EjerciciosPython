import uuid

from django.db import models
from django.urls import reverse


class Genre(models.Model):
    name = models.CharField(max_length=32, help_text="Nombre del género")

    def __str__(self):
        return self.name


class Movie(models.Model):
    title = models.CharField(max_length=64)
    director = models.ForeignKey('Director', on_delete=models.SET_NULL, null=True)
    summary = models.TextField(max_length=380, help_text="Sinopsis")
    duration = models.CharField(max_length=9, help_text="Duración en minutos")
    genre = models.ManyToManyField(Genre)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('movie-detail', args=[str(self.id)])


class MovieInstance(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, help_text="ID único")
    movie = models.ForeignKey('Movie', on_delete=models.SET_NULL, null=True)


class Director(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    date_of_birth = models.DateField(null=True, blank=True)
    date_of_death = models.DateField('Died', null=True, blank=True)

    def get_absolute_url(self):
        return reverse('author-detail', args=[str(self.id)])

    def __str__(self):
        return '%s, %s' % (self.last_name, self.first_name)