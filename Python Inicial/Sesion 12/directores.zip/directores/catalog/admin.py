from django.contrib import admin

from .models import Director, Genre, Movie, MovieInstance

admin.site.register(Director)
admin.site.register(Genre)
admin.site.register(Movie)
admin.site.register(MovieInstance)

